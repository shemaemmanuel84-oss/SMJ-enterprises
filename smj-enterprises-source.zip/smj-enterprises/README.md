# SMJ ENTERPRISES Website

## Android/cloud setup
1. Open GitHub Codespaces in Chrome on your Android phone, create a repository and upload/extract these files, then open a Codespace.
2. Run `npm install`, copy `.env.example` to `.env.local`, and configure your Supabase project credentials.
3. In Supabase SQL Editor run `supabase.sql`. In Supabase Authentication create an admin user. Copy the user's UUID and run `insert into admin_users(id,role) values ('USER_UUID','admin');` in SQL Editor.
4. Run `npm run dev`, then open forwarded port 3000. Test application submission and admin sign-in.
5. Deploy the GitHub repository on Vercel; add all environment variables in Vercel project settings, configure a custom domain, and verify HTTPS.

## Important production requirements
This is a functional starter, NOT a production-certified financial platform. Before accepting real personal information or money, obtain legal/privacy review, confirm Uganda lending registration/licensing requirements and all terms, replace the browser-set admin cookie with secure HttpOnly server-managed sessions, add rate limiting, bot protection, CSRF controls, field-level audit logging, backups, retention/deletion policy, monitoring, tests and a documented incident response plan. Do not use real applicant data until those controls are in place.

The application form stores data server-side in Supabase, but public submissions currently have no rate limiter. The admin dashboard provides sign-in, listing, search, status updates and CSV export. Loan/payment database tables and protected API read/record endpoints exist; a complete repayment-management interface, installment schedules, PDF/Excel exports, and loan origination workflows still need development. The 20% illustration is explicitly NOT assumed monthly or annual. Confirm the interest period, late fees, disclosures, and repayment schedule before launch.

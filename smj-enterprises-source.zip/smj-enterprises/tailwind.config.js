module.exports = { content: ['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'], theme: { extend: { colors: { navy:'#10263e', emerald:'#087f64', cream:'#f5f7f8', gold:'#b99a59' } } }, plugins: [] }

import {createClient} from '@supabase/supabase-js';
import {cookies} from 'next/headers';
export async function admin(){const token=(await cookies()).get('sb-access-token')?.value;if(!token||!process.env.SUPABASE_URL||!process.env.SUPABASE_ANON_KEY)return null;const client=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_ANON_KEY);const {data:{user}}=await client.auth.getUser(token);if(!user)return null;const {data}=await client.from('admin_users').select('role').eq('id',user.id).maybeSingle();return data?{id:user.id,role:data.role}:null}
